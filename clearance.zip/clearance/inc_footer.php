<div class="footer">
                        <div>
                            <strong>Otto Josiah</strong> - Copyright &copy; 2018
                        </div>
                    </div> <!-- end footer -->